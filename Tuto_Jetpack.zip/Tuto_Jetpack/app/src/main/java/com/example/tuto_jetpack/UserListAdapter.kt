package com.example.tuto_jetpack
/*
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.tuto_jetpack.databinding.ActivityMain2activityBinding
import com.example.tuto_jetpack.databinding.ItemMain2ActivityBinding

class UserListAdapter : ListAdapter<User, UserListAdapter.UserViewHolder>(UserDiffCallback()) {

    class UserViewHolder(val binding: ItemMain2ActivityBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(user: User) {
            binding.tvItemMain2Activity.text = user.nom

        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding = ItemMain2ActivityBinding.inflate(inflater, parent, false)
        return UserViewHolder(binding)
    }

    override fun onBindViewHolder(holder: UserViewHolder, position: Int) {
        val user = getItem(position)
        holder.bind(user)
    }
}
*/