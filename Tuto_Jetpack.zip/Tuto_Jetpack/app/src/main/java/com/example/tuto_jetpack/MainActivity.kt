package com.example.tuto_jetpack

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.activity.viewModels
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.fragment.app.commit
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.example.tuto_jetpack.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private val myViewModel : MainViewModel by viewModels()
    private lateinit var binding: ActivityMainBinding  // attention au nom



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

         binding =
            DataBindingUtil.setContentView(this, R.layout.activity_main)
        binding.viewModel = myViewModel
        binding.lifecycleOwner = this

        binding.btnFragmentAMainActivity.setOnClickListener {
            supportFragmentManager.commit {
                replace(R.id.fl_main_activity, FragmentA())
            }
        }

        binding.btnFragmentBMainActivity.setOnClickListener {
            supportFragmentManager.commit {
                replace(R.id.fl_main_activity, FragmentB())
        }
      }
    }
}
