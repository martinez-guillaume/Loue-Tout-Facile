package com.example.tuto_jetpack

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.coroutines.*
import androidx.activity.viewModels
import androidx.lifecycle.lifecycleScope
import com.example.tuto_jetpack.databinding.ActivityMain3Binding

class Main3Activity : AppCompatActivity() {
    private val colors = listOf(Color.RED, Color.GREEN, Color.BLUE)
    private val viewModel: MainViewModel by viewModels()
    private lateinit var binding: ActivityMain3Binding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMain3Binding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel.compteurLiveData.observe(this) { compteur ->
            binding.textView.text = compteur.toString()
        }

        binding.IncrementActivity3.setOnClickListener {
            viewModel.incrementer()
        }

        binding.btnChangeColorActivity3.setOnClickListener {
            CoroutineScope(Dispatchers.Main).launch {
                changeBackgroundColorAfterDelay()
            }
        }
    }

    private fun changeBackgroundColorDelay() {
        Thread.sleep(3000)
        val randomColor = colors.random()
        binding.clActivity3.setBackgroundColor(randomColor)
    }

    private suspend fun changeBackgroundColorAfterDelay() {
        lifecycleScope.launch {
        delay(3000)
        val randomColor = colors.random()
        binding.clActivity3.setBackgroundColor(randomColor)
        }
    }
}