package com.example.tuto_jetpack

import com.squareup.moshi.Json

data class JokeDto(
    @Json(name = "joke") val blague: String
)
