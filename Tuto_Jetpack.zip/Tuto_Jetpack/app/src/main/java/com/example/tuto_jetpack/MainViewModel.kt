package com.example.tuto_jetpack

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class MainViewModel : ViewModel() {

    //encapsulation          , On créer un LiveData   , bonne pratique _ avant le nom et private
    private val _compteurLiveData = MutableLiveData<Int>()

    // seul le LiveData non modifiable  est accessible de l'extérieur
    val compteurLiveData : LiveData<Int>
        get() = _compteurLiveData

    init { _compteurLiveData.value = 0 }

    fun incrementer(){
        _compteurLiveData.value = _compteurLiveData.value?.plus(1)
    }
}