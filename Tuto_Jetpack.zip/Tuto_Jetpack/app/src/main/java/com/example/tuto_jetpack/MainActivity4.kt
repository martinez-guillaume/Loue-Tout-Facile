package com.example.tuto_jetpack

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.example.tuto_jetpack.databinding.ActivityMain4Binding
import androidx.room.Room
import kotlinx.coroutines.*

class MainActivity4 : AppCompatActivity() {

    private lateinit var binding: ActivityMain4Binding

    private val db by lazy {
        Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java, "database-name"
        ).build()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMain4Binding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnSubmitActivity4.setOnClickListener {
            val firstName = binding.etFirstnameActivity4.text.toString()
            val lastName = binding.etNameActivity4.text.toString()

            // launch main par défaut
            CoroutineScope(Dispatchers.IO).launch {
                db.userDao().insertUser(User(firstName = firstName, lastName = lastName))
                val users = db.userDao().getAllUsers()

                withContext(Dispatchers.Main) {
                    binding.progressBar2.visibility = View.VISIBLE
                }
                delay(2000)

                withContext(Dispatchers.Main) {
                    binding.affichageNameAndFirstaneActivity4.text = users.joinToString("\n") { "${it.firstName} ${it.lastName}" }
                    binding.progressBar2.visibility = View.GONE
                }
            }
        }
    }
}
