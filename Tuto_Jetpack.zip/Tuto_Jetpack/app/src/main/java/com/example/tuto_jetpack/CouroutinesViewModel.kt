package com.example.tuto_jetpack

import androidx.lifecycle.ViewModel

class CouroutinesViewModel : ViewModel() {

}