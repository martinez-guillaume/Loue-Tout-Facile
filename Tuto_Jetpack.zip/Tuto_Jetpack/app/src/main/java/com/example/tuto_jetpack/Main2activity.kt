package com.example.tuto_jetpack

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class Main2activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2activity)

       /* val adapter = UserListAdapter()
        val recyclerView = findViewById<RecyclerView>(R.id.rv_main2_activity)

        recyclerView.layoutManager = LinearLayoutManager(this)

        recyclerView.adapter = adapter


        val firstList = listOf(User(1, "Alice"), User(2, "Bob"))
        adapter.submitList(firstList)*/
    }
}