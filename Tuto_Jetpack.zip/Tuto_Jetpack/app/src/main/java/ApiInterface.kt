import retrofit2.http.Query
import com.example.tuto_jetpack.JokeDto
import retrofit2.http.GET

interface ApiInterface {
    @GET("api")
    suspend fun getJoke(@Query("format") format: String): JokeDto
}